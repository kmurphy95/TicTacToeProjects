To run the extendedTicTacToe: 

1) type "make default" to compile all required .java files
2) type "make run" to run the application in GameScreen
3) type "make test" to compile all code including tests
4) type "make testGB" to run the tests for GameBoard
5) type "make testGBmem" to run the tests for GameBoardMem
6) type "make clean" to remove all compiled files from cpsc2150/extendedTicTacToe